# FilterTap Native Android APK Project
This is the complete, self-contained Android Studio project for FilterTap.

## How to Build the APK:

### Option 1: Android Studio (Recommended)
1. Open Android Studio.
2. Select "Open Project" and select the `android/` folder inside this zip.
3. Click "Build" > "Build Bundle(s) / APK(s)" > "Build APK(s)".
4. Your release/debug APK will be generated at `android/app/build/outputs/apk/debug/app-debug.apk`!

### Option 2: Command Line (Linux/macOS/WSL)
```bash
cd android
./gradlew assembleDebug
# or with signed key:
./gradlew assembleRelease
```

### Option 3: Android Phone direct build (Termux)
In Termux on Android:
```bash
pkg install openjdk-17 gradle
cd android
gradle assembleDebug
```
